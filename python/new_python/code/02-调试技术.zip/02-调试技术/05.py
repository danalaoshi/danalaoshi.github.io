import time
class BeTested(object):

    def __init__(self):
        self.var = 100
        self.name = "Name_0"

    def my1(self):
        self.var += 1
        return self.var

    def my2(self):
        self.var += 2
        return self.var

    def my3(self):
        self.var += 3
        return self.var

    def my4(self):
        self.var += 4
        return self.var
