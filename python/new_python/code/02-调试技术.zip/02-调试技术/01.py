
a = "i love chian"
b = "and you"

print(a + b)

c = 5
print(a + c)
