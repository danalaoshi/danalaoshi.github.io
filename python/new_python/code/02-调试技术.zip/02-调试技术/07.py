import unittest as ut
import importlib

bt = importlib.import_module("05")

class MyUT(ut.TestCase):

    def setUp(self):
        #global bt
        print("TESTING started............")
        self.o = bt.BeTested()

    def tearDown(self):
        print("TEST IS DONE !!!!!!!!!")

    def testMy1(self):
        print("Testing 1 ..............")
        v = self.o.var
        self.o.my1()
        self.assertEqual(v+1, self.o.var)

    def testMy2(self):
        print("Testing 2 ..............")
        v = self.o.var
        self.o.my2()
        self.assertEqual(v+2, self.o.var)
    def testMy3(self):
        print("Testing 3 ..............")
        v = self.o.var
        self.o.my3()
        self.assertEqual(v+3, self.o.var)
    def testMy4(self):
        print("Testing 4 ..............")
        v = self.o.var
        self.o.my4()
        self.assertEqual(v+4, self.o.var)

# suit是全局函数
def suite():
    suite = ut.TestSuite()
    suite.addTest(MyUT("testMy1"))
    suite.addTest(MyUT("testMy2"))
    return suite


# 测试
if __name__ == "__main__":
    ut.main(defaultTest='suite')

