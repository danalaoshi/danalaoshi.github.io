import unittest as ut
import importlib

bt = importlib.import_module("05")

class MyUT(ut.TestCase):

    def setUp(self):
        #global bt
        print("TESTING started............")
        self.o = bt.BeTested()

    def tearDown(self):
        print("TEST IS DONE !!!!!!!!!")

    def testMy1(self):
        v = self.o.var
        self.o.my1()
        self.assertEqual(v+1, self.o.var)

    def testMy2(self):
        v = self.o.var
        self.o.my2()
        self.assertEqual(v+2, self.o.var)
    def testMy3(self):
        v = self.o.var
        self.o.my3()
        self.assertEqual(v+3, self.o.var)
    def testMy4(self):
        v = self.o.var
        self.o.my4()
        self.assertEqual(v+4, self.o.var)

if __name__ == "__main__":
    # 第一种调用，完全运行
    #ut.main()

    # 第二种调用，单个使用
    # 需要手动调用setUP
    print("hahhahaha")
    u = MyUT()
    u.setUp()
    u.testMy1()
