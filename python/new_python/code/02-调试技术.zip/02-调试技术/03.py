import pdb
pdb.set_trace()
def func(n):
    for i in range(1,n):
        print("LOOP {0} ".format(i))

    print("Func is done!!!")

if __name__ == "__main__":
    print("Start my software..........")
    func(10)
    print("Software is done !!!!!!!!")